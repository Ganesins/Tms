<?php
$a0=$_POST['c0'];
$a1=$_POST['c1'];
$a2=$_POST['c2'];
$a3=$_POST['c3'];
$a4=$_POST['c4'];
$a5=$_POST['c5'];
$a6=$_POST['c6'];
$a7=$_POST['c7'];
$a8=$_POST['c8'];
$a9=$_POST['c11'];
$a10=$_POST['c14'];
$a11=$_POST['c15'];
$a12=$_POST['c16'];
$a13=$_POST['c17'];
$a15=$_POST['tc1'];
$a16=$_POST['tc2'];
$a17=$_POST['tc3'];
$a18=$_POST['tc4'];
$a19=$_POST['tc5'];

$link=mysqli_connect("localhost","root","","vgs");

if($link==false)
{
	die("Error:could not connect.".mysqliconnect_error());
}
$sql="INSERT INTO invoicenew(`customername`, `invoiceno`, `orderno`, `invoicedate`, `terms`, `duedate`, `salesperson`, `subject`, `itemdetails`, `quantity`, `rate`, `discount`, `amount`, `subtotal`, `tax`, `othercharges`, `total`, `termscondition`, `attachfile`) VALUES ('$a0','$a1','$a2','$a3','$a4','$a5','$a6','$a7','$a15','$a16','$a17','$a18','$a19','$a8','$a9','$a10','$a11','$a12','$a13')";
if(mysqli_query($link,$sql))
{
echo"records added successfully";
}

else{
	echo "ERROR:COULD NOT BE EXECUTE $sql.".mysqli_error($link);
}
header("location:allinvoic.php");
mysqli_close($link);

?>
