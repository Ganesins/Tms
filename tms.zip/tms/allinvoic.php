<?php
include ("nav.php");
?>
<?php
include ("side.php");
?>
<style>
.cus0{
	font-size: 30px;
	font-weight: bold;
}
.new1{
	float: right;
}
	
</style>
<section id="main-content">

      <section class="wrapper">
      	<p class="cus0">ALL INVOICE</p>

      	
      	<select style="width:10%;"
        onchange="location =this.value;">
  <option value="allinvoic.php">ALL INVOICE</option>
 <option value="activeinvoic.php">PAID INVOICE</option>
  <option value="inactiveinvoic.php">UNPAID INVOICE</option>
  
</select>
<div class="new1">
 <a href="newcu.php"><button type="AddItem" class="btn btn-round btn-primary">
  <i class=" fa fa-plus"> Add customer</i></button></a>
 </div>
<div class="row mt">
       <div class="col-md-12">
         <div class="content-panel">
          <table class="table table-striped table-advance table-hover">
                <!-- <h4><i class="fa fa-angle-right"></i> Advanced Table</h4>
                <hr> -->
                <thead>
                  <tr>
                    <th>DATE</th>
                    <th>INVOICE#</th>
                    <th>ORDERNO</th>
                    <th>CUSTOMER NAME</th>
                    <th>STATUS</th>
                    <th>DUE DATE</th>
                    <th>AMOUNT</th>
                    <th>BALANCE DUE</th>
                  </tr>
                </thead>
            <tbody>
               <?php
                  $link=mysqli_connect("localhost","root","","vgs");
                   if($link==false)
                   {
                   	die("error:cant connect".mysqli_connect_error());
                   }
                   $sql="SELECT* FROM invoicenew";
                   if($result=mysqli_query($link,$sql))
                   {
                   	if(mysqli_num_rows($result)>0)
                   	{ 
                      
                   		while($row= mysqli_fetch_array($result))

                    {
                    
                     ?>
                 <tr>
                
                   <td>
                      <a href="basic_table.html#"><?php echo$row['invoicedate']; ?></a>
                    </td>
                    <td class="hidden-phone"><?php echo$row['invoiceno']; ?></td>
                    <td><?php echo$row['orderno']; ?></td>
                    <td><?php echo$row['customername']; ?></td>
                    <td><?php echo$row['terms']; ?></td>
                    <td><?php echo$row['duedate']; ?></td>
                    

                    <td><i class="fa fa-rupee"></i><?php echo$row['amount']; ?></td>
                    <td><i class="fa fa-rupee"></i><?php echo$row['discount']; ?></td>
                    <td>
                      <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                      
                       <a href="editin.php?id=<?php echo$row['invoiceno'];?>"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a>
                       <a href="deletein.php?id=<?php echo$row['invoiceno'];?>"> <button class=" btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button></a>
                   </td>
                 </tr> 
                 <?php  } } }?>
             </tbody>
          </table>
         </div>
     </div>

           
            <!-- /content-panel -->
          
          <!-- /col-md-12 -->
</div>
      </section>
</section>
		