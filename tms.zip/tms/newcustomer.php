<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
  
  <?php
include ("nav.php");
include 'side.php';
?>
<!-- <?php
;
?> -->
</head>
<body>
<section id="main-content">
      <section class="wrapper">
<!-- page start-->
      <!-- <div class="header"> -->
        <p style="font-size: 30px;">NEW CUSTOMER</p>
        <label>customer tybe</label>
        <input type="radio" name="customer_choice">
        <label>individual</label>
        <input type="radio" name="customer_choice">
        <label>business</label>
     <div class="vel1">
       <label class="vel">CUSTOMER NAME</label><br>
     </div>
     <div class="vel">
       <input type="text" name="a"><br>
      </div>
       <label class="vel">COMPANY NAME</label><br>
       <input type="text" name="a"><br>
       <label class="vel">CUSTOMER PHONE</label><br>
       <input type="text" name="a"><br>
       <label class="vel">CUSTOMER EMAIL</label><br>
       <input type="text" name="a"><br>
       <label class="vel">CUSTOMER WEBSITE</label><br>
       <input type="text" name="a"><br>
       <a href="newcuadd.php"><button type="button" class="btn btn-round btn-primary">ADDRESS</button></a>
      <a href="newcuper.php"><button type="button" class="btn btn-round btn-success">CONTACT PERSONS</button></a>
      <a href="newcure.php"> <button type="button" class="btn btn-round btn-info">REMARKS</button></a><br><br>
      <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Home</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Profile</button>

   
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Contact</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false" disabled>Disabled</button>
  </li>
</ul>
<div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">hello</div>
  <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">hi</div>
  <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">how are you</div>
  <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">dnkja</div>
</div><br><br>
<button type="submit" class="btn btn-theme">Save</button>
<button type="submit" class="btn btn-theme">cancel</button>
</body>
     0
      </section>
      <!-- /wrapper -->
    </section>
    </html>
