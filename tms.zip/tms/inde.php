<?php
include ("head.php");
include("nav.php");
 ?>
  <section id="main-content">
      <section class="wrapper">
        <!-- page start-->
    
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->

 <?php
 include ("footer.php");
 ?>
