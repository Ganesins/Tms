<?php
$a2=$_GET['id'];
$link = mysqli_connect("localhost","root","","vgs");
if($link==false)
  {
	die("ERROR:COULD NOT BE CONNECT.".mysqli_connect_error());
  }
  $sql = "DELETE FROM newcustomer WHERE customerphone='$a2'";
  if(mysqli_query($link,$sql))
  {
  	echo "records were deleted successfuly.";
  }
  else
  {
  	echo "ERROR:could not able to execute$sql.".mysqli_error($link);

  }
  header("location:allcustomer.php");
  mysqli_close($link);
  ?>
