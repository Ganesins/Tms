<?php
include ("nav.php");
?>
<?php
include ("side.php");
?>
<section id="main-content">
      <section class="wrapper">
<!-- page start-->
                  <?php
                  $a2=$_GET['id'];

                  $link=mysqli_connect("localhost","root","","vgs");
                   if($link==false)
                   {
                    die("error:cant connect".mysqli_connect_error());
                   }
                   $sql="SELECT*FROM newcustomer where customerphone='$a2'";
                   if($result=mysqli_query($link,$sql))
                   {
                    if(mysqli_num_rows($result)>0)
                    { 
                      
                      while($row= mysqli_fetch_array($result))

                    {
                    
                     ?>    

      <!-- <div class="header"> -->
      <form action="updatecu.php" method="POST">
        <p style="font-size: 28px; margin-left: 11em;" >EDIT CUSTOMER</p>
        <label>customer tybe</label>
        <input  style="margin-left: 40px;" type="radio" name="a0" value="individual">
        <label>individual</label>
        <input type="radio" name="a0" value="business">
        <label>business</label><br><br>
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">CUSTOMER NAME</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control" name="a1" value="<?php echo$row['customername'];?>"><br>
                  </div>
    </div>
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">COMPANY NAME</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;"  type="text" class="form-control" name="a2" value="<?php echo$row['companyname'];?>"><br>
                  </div>
    </div>
    <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label">CUSTOMER PHONE</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control" name="a3" value="<?php echo$row['customerphone'];?>"><br>
                  </div>
    </div>
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">CUSTOMER Email</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="Email" class="form-control" name="a4" value="<?php echo$row['customeremail'];?> "><br>
                  </div>
    </div>
    <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label">CUSTOMER WEBSITE</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control" name="a5" value="<?php echo$row['customerwebsite'];?>"><br>
                  </div>
    </div>
           <input type="hidden" name="a8" value="<?php echo$row['customerno'];?>" >

     <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label">PAN</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control" name="a6" value="<?php echo$row['pan'];?>"><br>
                  </div>
    </div>
     <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label">PAYMENT TERMS</label>
                   <select style="width: 20em; height: 30PX; margin-left: 20px;" name="a7" value="<?php echo$row['paymentterms'];?>">
                  <option>DUE ON RECEIPT</option>
                  <option>DUE END OF THE MONTH</option>
                  <option>DUE END OF NEXT MONTH</option>
                  <option>NET 50</option>
                  <option>NET 30</option>
                </select>
    </div>
    <a href="newcuadd.php"><button type="button" class="btn btn-round btn-primary">ADDRESS</button></a>
      <a href="newcuper.php"><button type="button" class="btn btn-round btn-success">CONTACT PERSONS</button></a>
       <a href="newcure.php"><button type="button" class="btn btn-round btn-info">REMARKS</button></a><br><br><br>
       <button type="submit" class="btn btn-theme">Save</button>
     </form>  
    <!-- <a href="newcu.php"><button type="submit" class="btn btn-theme">cancel</button></a> -->
    <?php  } } }?>
    
      </section>
      <!-- /wrapper -->
    </section>