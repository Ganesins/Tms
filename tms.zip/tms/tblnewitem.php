<?php
$a1=$_POST['r1'];
// echo$a1;
// echo"working";
$a2=$_POST['r2'];
$a3=$_POST['r3'];
$a6=$_POST['r6'];



$link=mysqli_connect("localhost","root","","tms");
if($link==false)
{
	
	die("error can't connected".mysqli_connect_error());
}
$sql="INSERT INTO master(course, package, duration,date) VALUES ('$a1','$a2','$a3','$a6')";

if(mysqli_query($link,$sql))
{
	echo "records added scuccessfully";


header("location:newcourse.php");



}

else
{
	echo "unable to excecute".mysqli_error($link);
}



mysqli_close($link)
?>

$sql="INSERT INTO newestimate(customername, estimateno, estimatedate, expitrydate, salesperson) VALUES ('$a1','$a2','$a3')";