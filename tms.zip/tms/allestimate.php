<?php
include ("head.php");
include("nav.php");
 ?>
 <style>
     
 </style>
 <section id="main-content">
      <section class="wrapper">
          <!-- page start-->
    <!-- row -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                  <a href="newestimate.php">
                    <button type="AddItem" class="btn btn-round btn-primary" style="float: right; margin-right: 20px;">
                      <i class=" fa fa-plus">New Estimate</i></button></a>
                <h4>  
                  <select name="" onchange="location=this.value" >
                    <option value="allestimate.php">All Estimate</option>
                    <option value="declinedestimate.php">Declined Estimate</option>
                    <option value="acceptedestimate.php">Accepted Estimate</option>
                 </select>
               </h4>
               

                <hr>
                <thead>
                  <tr>
                    <th><i class="fa fa-bookmark"></i> Date</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> EstimateNumber</th>
                    <th><i class="fa fa-money"></i> Customername</th>
                    <th><i class=" fa fa-bullhorn"></i> Status</th>
                    <th><i class=" fa fa-money"></i>Amount</th>
                    <th><i class=" fa fa-edit"></i>Editchanges</th>

                  </tr>
                </thead>
                <tbody>   

                <?php
$link=mysqli_connect("localhost","root","","vgs");
if($link==false)
{
  die("error:cant connect".mysqli_connect_error());

}
$sql="SELECT*FROM newestimate";
if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)){
  echo "<table border='3'>";
  echo"<tr>";
  echo"<th>customername</th>";
  echo"<th>estimateno</th>";
  echo"<th>estimatedate</th><br>";
  echo"<th>expirydate</th>";
  echo"<th>salesperson</th>";
  echo"<th>subtotal </th>";
  echo"</tr>";
  while($row= mysqli_fetch_array($result))
  {
  echo"<tr>";
  echo"<td>".$row['customername']."</td>";
  echo"<td>".$row['estimateno']."</td>";
  echo"<td>".$row['estimatedate']."</td>";
  echo"<td>".$row['expirydate']."</td>";
  echo"<td>".$row['salesperson']."</td>";
  echo"<td>".$row['subtotal']."</td>";

  echo"</tr>";

  }
  echo"</table>";
  mysqli_free_result($result);
}
else
{
  echo"no match found";
}
}
else
{
  echo"error;cant execute $sql.".mysqli_error($link);
}
mysqli_close($link);

?>

 
    <!-- row -->
                 <tr>
                    <td>
                      <a href="basic_table.html#"><--?php echo$row['name']; ?--></a>
                    </td>
                    <td class="hidden-phone"><--?php echo$row['description']; ?--></td>
                    <td><-- ?php echo$row['sellingprice']; ?> --></td>
                    <td><-- ?php echo$row['sellingprice']; ?> --></td>

                    <td><span class="label label-info label-mini">-----</span></td>
                    <td>
                      <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                      <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                      <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                    </td>
                  </tr>
                 
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->




      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->








