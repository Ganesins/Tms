<?php
include ("head.php");
include("nav.php");
 ?>
 <style>
  *{
    font-weight: bold;
  }
  .br{
    margin-top: 15px;
  }
  .right{
    float: right;
    margin-right: 20%;
   
  }
  .down{ margin-top: 20%;}
 .subtotal{margin-left: 46%;}
 .entertax{margin-left: 3%;}
 .taxname{margin-left: 10%;}
 .total{margin-left: 48%;}
     
 </style>

  <section id="main-content">
      <section class="wrapper">
          <!-- page start-->
        

<form action="tblnewestimate.php" method="post">
<!-- page start-->
      <!-- <div class="header"> -->
        <p style="font-size: 28px;" >NEW Extimate</p><br>
       
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">CUSTOMER NAME*</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control" name="customername"><br>
                  </div>
    </div>
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Estimate No</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;"  type="text" class="form-control" name="estimateno"><br>
                  </div>
    </div>
    <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label">Extimate Date*</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="date" class="form-control" name="d1"  value="<?php echo date('Y-m-d'); ?>">
                    <br>
                  </div>
                  <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label">Expiry Date</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="date" class="form-control" name="d2"  value="<?php echo date('Y-m-d'); ?>">
                    <br>
                  </div>
 
    <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label">SalesPerson</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control" name="salesperson"><br>
                  </div>

              </div>
            </div>
          </div>
        </div>

      <h3>Items</h3>

 <table  class="table table-bordered table-striped">
    <thead>
     <tr>
      <th>ItemDetials</th>
      <th>Quantity</th>
      <th>Rate</th>
      <th>Discount</th>
      <th>Amount</th>
     </tr>
  </thead>
    <tbody>
       <tr>
       <td >1</td>
       <td>Mark</td>
       <td>Otto</td>
       <td>@mdo</td>
       <td>eudksja@sdj.com  <i class=" fa fa-copy"></i>
 </td>
       
       
      </tr>
      </tbody>
    </table>
         <button type="AddItem" class="btn btn-round btn-primary">
    <i class=" fa fa-plus"> Add Item</i></button></a>
   
  
     <div class="right">
       <label>SubTotal:</label>
       <input type="text"  class="br subtotal" name="subtotal"><br>
       <label>Tax  :</label>
       <input type="text" name="taxname" class="taxname" placeholder="Tax Name">
       <input type="number" placeholder="Enter Tax   (%)" class="br entertax " name="tax"> <br>
       <label class="othercharge">other charges</label>
       <input type="text" placeholder="charges for" class="br" name="chargesfor">
       <input type="number" class="br" name="charges"><br>
       <label>Total:<i class="fa fa-money"></i> </label>
       <input type="text" class="br total" name="total">
     </div><br>
      <div class="down">
      <label >Customer Notes</label>
      <textarea class="form-control" name="customernote" id="examplFormControlTextarea1" rows="3" style="width: 50%"></textarea><br>
      <label >Terms & condition </label>
      <textarea class="form-control" name="terms" id="examplFormControlTextarea1" rows="3" style="width: 70%"></textarea><br>
      <div class="right"  >

      <label>attach file(s)toEstimate </label>
      <input type="file" name="file" >
      <label>you can upload maximum 5mp</label>
    </div>

    <button class="btn btn-theme" type="submit">Save</button>

      <button type="reset" class="btn btn-round btn-success">cancel</button></a>
      </form>
  </div>
</section>
</section>

      <!-- /wrapper -->
 
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->