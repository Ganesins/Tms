<?php
$a1=$_POST['customername'];
$a2=$_POST['estimateno'];
$a3=$_POST['d1'];
$a4=$_POST['d2'];
$a5=$_POST['salesperson'];
$a6=$_POST['subtotal'];
$a7=$_POST['taxname'];
$a8=$_POST['tax'];
$a9=$_POST['chargesfor'];
$a10=$_POST['charges'];
$a11=$_POST['total'];
$a12=$_POST['customernote'];
$a13=$_POST['terms'];
$a14=$_POST['file'];


$link=mysqli_connect("localhost","root","","vgs");
if($link==false)
{
	
	die("error can't connected".mysqli_connect_error());
}

$sql="INSERT INTO `newestimate`( customername,estimateno,estimatedate,expirydate,salesperson,subtotal,taxname,taxpercent,otherchargename,charges,total,customernote,terms,file) VALUES ('$a1','$a2','$a3','$a4','$a5','$a6','$a7','$a8','$a9','$a10'.'$a11','$a12','$a13','$a14')"  ;
echo "$sql";
if(mysqli_query($link,$sql))
{
	echo "records added scuccessfully";

}

else
{
	echo "unable to excecute".mysqli_error($link);
}

header("location:allitems.php");

mysqli_close($link);
?>
