<?php
include ("head.php");
include("nav.php");
 ?>
 <style>
  .br{
    margin-top: 15px;
  }
  .right{
    float: right;
    margin-right:15%;
    border-style:dashed;
    margin-bottom: 5%;
    margin-top: 2%;
   
  }
 .botmargin{
  margin-bottom: 40px;
 }
  .notebottom{
    margin-top: 20%;
  }
     
 </style>

  <section id="main-content">
      <section class="wrapper">
          <!-- page start-->
        

<form action=".php" method="post">
<!-- page start-->
      <!-- <div class="header"> -->
        <p style="font-size: 28px;" >Edit Payment</p><br>
       
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">CUSTOMER NAME*</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" placeholder="select Customer" class="form-control" name="a1">
                    <label class="botmargin">view customer details</label>
                  </div>
              </div>

              <label>Amount Recived</label>
              <input type="number" name="">
              <label>bankcharges (if any)</label>
              <input type="number" name=""><br><br>
              

    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Payment Date</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;"  type="date" class="form-control" name="a2"><br>
                  </div>
    </div>
    <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label">Payment Number</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="number" class="form-control" name="a3">
                    <br>
                  </div>
                  <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label">Payment Mode</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control" name="a3">
                    <br>
                  </div>
 
    <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label">SalesPerson</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control" name="a5"><br>
                  </div>

                  <label>Include Tax ?</label>
                  <input type="radio" name="z1" value="yes">
                  <label>Yes</label>
                  <input type="radio" name="z1" value="no">
                  <label>No</label>
                  <br><br>

   
     <button type="save" class="btn btn-round btn-primary">save</button></a>
    <button type="reset" class="btn btn-round btn-success">cancel</button></a>

              </div>
            </div>
          </div>
        </div>
      </form>

      <h3>Items</h3>

 <table  class="table table-bordered table-striped">
    <thead>
     <tr>
      <th>Date</th>
      <th>invoice Number</th>
      <th>invoice Amount </th>
      <th>Amount Date</th>
      <th>Payment</th>
     </tr>
  </thead>
    <tbody>
       <tr>
       <td >1</td>
       <td>Mark</td>
       <td>Otto</td>
       <td>@mdo</td>
       <td>eudksja@sdj.com  <i class=" fa fa-copy"></i>
 </td>
       
       
      </tr>
      </tbody>
    </table>
       
    <div class="right">
       <label>Amount Recived</label>
       <input type="text" style="margin-left: 18%;" class="br" name=""><br>
       <label>Amount used for Payment</label>
       <input type="number" placeholder="select tax" style="margin-left:0%;" class="br" name=""><br>
       <label>Amount Refunded: </label>
       <input type="text" placeholder="charges for" style="margin-left: 13%;" class="br" name=""><br>
       <label>Total:<i class="fa fa-money"></i> </label>
       <input type="text" style="margin-left: 32%;" class="br" name="">
     </div><br>
      <div>
     <!--  <label >Amount excess</label>
      <textarea class="form-control" id="examplFormControlTextarea1" rows="3" style="width: 70%"></textarea><br> -->
      <label  class="notebottom">Notes </label>
      <textarea class="form-control" id="examplFormControlTextarea1" rows="2" style="width: 80%"></textarea><br>  
      <div class="righ"  >
      <label>attach file(s)toEstimate </label>
      <input type="file" name="" value="choose">
      <label>you can upload maximum 5mp</label>
    </div>
      
<button type="save" class="btn btn-round btn-primary">save</button></a>
  <button type="send" class="btn btn-round btn-success">send</button></a>
     <button type="cancel" class="btn btn-round btn-primary">cancel</button></a>


    </div>




   
     
      <!-- /wrapper -->
 
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
















      <!-- /wrapper -->
 
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->