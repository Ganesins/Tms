<?php
include ("nav.php");
?>
<?php
include ("side.php");
?>
<style>
.cus0{
	font-size: 30px;
	font-weight: bold;
}
.new1{
	float: right;
}
	
</style>
<section id="main-content">

      <section class="wrapper">
      	<p class="cus0">ALL CUSTOMER</p>

      	
      	<select style="width:10%;" class="cus1" aria-label=".form-select-sm example  ">
  <option selected>ALL CUSTOMER</option>
  <option value="1">ACTIVE CUSTOMER</option>
  <option value="2">INACTIVE CUSTOMER</option>
  <option value="3">OVERDUE CUSTOMER</option>
  <option value="4">UNPAID CUSTOMER</option>
</select>
<div class="new1">
 <a href="newcu.php"><button type="AddItem" class="btn btn-round btn-primary">
  <i class=" fa fa-plus"> Add customer</i></button></a>
 </div>
<div class="row mt">
       <div class="col-md-12">
         <div class="content-panel">
          <table class="table table-striped table-advance table-hover">
                <!-- <h4><i class="fa fa-angle-right"></i> Advanced Table</h4>
                <hr> -->
                <thead>
                  <tr>
                    <th>NAME</th>
                    <th>company name</th>
                    <th>email</th>
                    <th>work phone</th>
                    <th>receivables</th>
                    <th>unused credits</th>
                  </tr>
                </thead>
            <tbody>
               <?php
                  $link=mysqli_connect("localhost","root","","vgs");
                   if($link==false)
                   {
                   	die("error:cant connect".mysqli_connect_error());
                   }
                   $sql="SELECT*FROM Newcustomer";
                   if($result=mysqli_query($link,$sql))
                   {
                   	if(mysqli_num_rows($result)>0)
                   	{ 
                      
                   		while($row= mysqli_fetch_array($result))

                    {
                    
                     ?>
                 <tr>
                
                   <td>
                      <a href="basic_table.html#"><?php echo$row['customername']; ?></a>
                    </td>
                    <td class="hidden-phone"><?php echo$row['companyname']; ?></td>
                    <td><?php echo$row['customeremail']; ?></td>
                    <td><?php echo$row['customerphone']; ?></td>
                    <td><i class="fa fa-rupee"></i><?php echo$row['pan']; ?></td>
                    <td><i class="fa fa-rupee"></i><?php echo$row['paymentterms']; ?></td>
                    <td>
                      <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                      <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                      <a href="deletecu.php?id=<?php echo$row['customerphone'];?>><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button></a>
                   </td>
                 </tr> 
                 <?php  } } }?>
             </tbody>
          </table>
         </div>
     </div>

           
            <!-- /content-panel -->
          
          <!-- /col-md-12 -->
</div>
      </section>
</section>
		