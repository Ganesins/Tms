<?php
$b0=$_POST['a0'];
$b1=$_POST['a1'];
$b2=$_POST['a2'];
$b3=$_POST['a3'];
$b4=$_POST['a4'];
$b5=$_POST['a5'];
$b6=$_POST['a6'];
$b7=$_POST['a7'];
$b8=$_POST['a8'];

$link = mysqli_connect("localhost","root","","vgs");
if($link==false)
  {
	die("ERROR:COULD NOT BE CONNECT.".mysqli_connect_error());
  }
  $sql = "UPDATE `newcustomer` SET `customertype`='$bo',`customername`='$b1',`companyname`='$b2',`customerphone`='$b3',`customeremail`='$b4',`customerwebsite`='$b5',`pan`='$b6',`paymentterms`='$b7' WHERE customerno='$b8'";
  if(mysqli_query($link,$sql))
  {
  	echo "records were deleted successfuly.";
  }
  else
  {
  	echo "ERROR:could not able to execute$sql.".mysqli_error($link);

  }
  header("location:allcu.php");
  mysqli_close($link);
  ?>
