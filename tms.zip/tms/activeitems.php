<?php
include ("head.php");
include("nav.php");
 ?>
  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->



        <a href="newitem.php">
         <button type="AddItem" class="btn btn-round btn-primary" style="float: right; margin: 20px; margin:;">
             <i class=" fa fa-plus">New Item</i></button></a>

    <h3>Active Items</h3>
      <select name="" onchange="location = this.value;" >
                     <option  value="activeitems.php">Active</option>
                      <option value="allitems.php">All</option>
             <option value="inactiveitems.php">Inactive</option>

      
    </select>

  <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <hr>
                <thead>
                  <tr>
                    <th> itemno</th>
                    <th><i class="fa fa-bullhorn"></i> NAME</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Descrition</th>
                    <th><i class="fa fa-money"></i> Rate</th>
                    <th><i class=" fa fa-edit"></i> Status</th>
                    <th><i class=" fa fa-bookmark"></i>Action</th>

                    <th></th>
                  </tr>
                </thead>
                <tbody>    
    <!-- row -->

<?php

            $a1=$_GET['id'];
            $a2=$_GET['id'];

            $a3=$_GET['id'];

            $a4=$_GET['id'];

            $a=$_GET['id'];


echo$a2;
echo"work";



$link=mysqli_connect("localhost","root","","vgs");
if($link==false)
{
  
  die("error can't connected".mysqli_connect_error());
}

$sql="INSERT INTO activeitem (itemno) VALUES ('100')";

echo "$sql";

// if(mysqli_query($link,$sql))
// {
//   echo "records added scuccessfully";


// header("location:newitem.php");



// }

// else
// {
//   echo "unable to excecute".mysqli_error($link);
// }



// mysqli_close($link)
?>

    <?php

            $a1=$_GET['id'];

$link=mysqli_connect("localhost","root","","vgs");
if($link==false)
{
  die("error:cant connect".mysqli_connect_error());

}
        $sql="SELECT * FROM newitem where itemno='$a1'";
if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
  // echo "<table border='3'>";
  // echo"<tr>";
  // echo"<th>type</th>";
  // echo"<th>name</th>";
  // echo"<th>unit</th><br>";
  // echo"<th>sellingprice</th>";
  // echo"<th>description</th>";
  // echo"<th>date</th>";
  // echo"</tr>";
  while($row= mysqli_fetch_array($result))
  {
//   echo"<tr>";
//   echo"<td>".$row['type']."</td>";
//   echo"<td>".$row['name']."</td>";
//   echo"<td>".$row['unit']."</td>";
//   echo"<td>".$row['sellingprice']."</td>";
//   echo"<td>".$row['description']."</td>";
//   echo"<td>".$row['date']."</td>";

//   echo"</tr>";

//   }
//   echo"</table>";
//   mysqli_free_result($result);
// }
// else
// {
//   echo"no match found";
// }
// }
// else
// {
//   echo"error;cant execute $sql.".mysqli_error($link);
// }
// mysqli_close($link);

?>


          
     
                  <tr>
                    <td> <?php echo$row['itemno'];?></td>
                    <td>
                      <a href="itemoverview.php"><?php echo$row['name']; ?></a>
                    </td>
                  <td class="hidden-phone"><?php echo$row['description']; ?></td>
                    <td><?php echo$row['sellingprice']; ?></td>
                    <td><span><div class="btn-group">
                <button type="button" class="btn btn-theme03">Status</button>
                <button type="button" class="btn btn-theme03 dropdown-toggle" data-toggle="dropdown">
                  <span class="caret"></span>
                  <span class="sr-only">Toggle Dropdown</span>
                  </button>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="updactive.php?id=<?php echo$row['itemno'];?>">
                  active</a></li>
                  <li><a href="#">inavtive</a></li>
                 
                </ul>
              </div>
            </div></span></td>
                    <td>
                      
                      <!-- <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button-->

                      <a href="edititem.php?id=<?php echo$row['itemno'];?>">
        <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i>
        </button></a>

                  <a href="delnewitem.php?id=<?php echo $row['itemno'];?>">
                    <button style="margin-left: 10px;" class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button></a>

                    </td>
                  </tr>
                  <?php  }  } } ?>
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->




      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->








