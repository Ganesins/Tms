<?php

$a2=$_GET['id'];
echo$a2;
echo"work";
	$link=mysqli_connect("localhost","root","","tms");
	if($link==false)
	{
			
		
		die("error cant connected".mysqliconnect_error());
	}
	
	
$sql="DELETE FROM `master` WHERE id='$a2'";

	// $sql="UPDATE `newitem`SET type='product',name='tomato',unit='5kg',sellingprice='450',description='testing' where itemno='$a2'";



	if(mysqli_query($link,$sql))

	{
		echo"records deleted succssfully";
	}
	else
	{
		echo"cant able to excecuted".mysqli_error($link);
	}
	
	header("location:allcourse.php");
	mysqli_close($link)
?>	