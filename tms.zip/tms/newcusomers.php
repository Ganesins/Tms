<?php
include ("head.php");
include("nav.php");
 ?>
  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->

new cusmomers
      <!-- /wrapper -->
    </section>
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->



