<?php
include ("head.php");
include("nav.php");
 ?>
 
  <style>
    .spacer{
       margin-right: 50px;

    }

    
  </style>

  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->

        <?php
        $a1=$_GET['id'];
        $link=mysqli_connect("localhost","root","","tms");
        if($link==false)
        {
         die("error:can't connect".mysqli_connect_error());
        }

        $sql="SELECT * FROM master where id='$a1'";
        if($result=mysqli_query($link,$sql)){ 
         if(mysqli_num_rows($result)>0){

              // echo "<table border='2'>";
              // echo "<tr>";
              // echo "<th>type</th>";
              // echo "<th>name</th>";
              // echo "<th>unit</th>";
              // echo "<th>selling price</th>";
              // echo "<th>Description</th>";
              // echo "</tr>";
              while($row= mysqli_fetch_array($result))
              {
              //   echo "<tr>";
              //   echo"<td>".$row['type']."</td>";
              //   echo "<td>".$row['name']."</td>";
              //   echo "<td>".$row['unit']."</td>";
              //   echo "<td>".$row['sellingprice']."</td>";
              //   echo "<td>".$row['description']."</td>";
              //   echo "</tr>";
              // }
          //     echo "</table>";
          //     mysqli_free_result($result);
          //   }
          //   else
          //   {
          //     echo"match not found";

          //   }
          // }
          //   else
          //   {
          //     echo "error in sql".mysqli_error($link);
          //   }
          //   mysqli_close($link)
          

        ?>

   <form action="upditem.php" method="post">  




   
    <h3>Edit course</h3>
        <input type="hidden" name="hide1" value='<?php echo$a1;?>'>

<label>Newcourse</label><br>
<input type="text" name="r2" value="<?php echo$row['course']; ?>"><br><br>
<label>package</label><br>
   <input type="text" name="r3" value='<?php echo$row['package']; ?>'> <br><br>
    <label>duration</label><br>
    <input type="text" name="r4" value='<?php echo$row['duration']; ?>'><br><br>
     <!--  <label>  Description</label><br>
      <input type="text" name="r5" value="<?php echo$row['descrip'];?>"> -->
    <?php }}} ?>
              <br><br><br>
<input type="submit" name="" value="save">
<button>cancel</button>
</form>

<!-- item added successfully notification -->

   <!-- /wrapper -->
    </section>
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->



