<?php
include ("nav.php");
?>
<?php
include ("side.php");
?>
<style>
.cus0{
	font-size: 30px;
	font-weight: bold;
}
	
</style>
<section id="main-content">

      <section class="wrapper">
      	<p class="cus0">ALL CUSTOMER</p>
      	<select style="width:10%;" class="cus1" aria-label=".form-select-sm example  ">
  <option selected>ALL CUSTOMER</option>
  <option value="1">ACTIVE CUSTOMER</option>
  <option value="2">INACTIVE CUSTOMER</option>
  <option value="3">OVERDUE CUSTOMER</option>
  <option value="4">UNPAID CUSTOMER</option>
  <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Advanced Table</h4>
                <hr>
                <thead>
                  <tr>
                    <th><i class="fa fa-bullhorn"></i> NAME</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Descrition</th>
                    <th><i class="fa fa-money"></i> Rate</th>
                    <th><i class=" fa fa-edit"></i> Status</th>
                    <th><i class=" fa fa-bookmark"></i> </th>

                    <th></th>
                  </tr>
                </thead>
                <tbody>    
    <!-- row -->

</select>
      </section>
</section>
