<?php
include 'nav.php';
include 'side.php';
?>
<style>
	.invoi1{
		border-bottom: 1px solid grey;

	}
	.invoi1 p{
		font-size: 40px;
		font-weight: bolder;

	}
	.invoi1 i{
		margin-right: 10px;
	}
	label {
		font
	}
	.invoi3{
		margin-top: 20px;
	
	}
	.invoi5{
		margin-top: 10px;
	}
	.invoi2 input{
		width: 40%;
		height: 30px;
		border-radius: 5px;
		border-bottom:2px solid black; 
		margin-left: 30px;
	}
	.invoi3 input{
		width: 25%;
		height: 30px;
		border-radius: 5px;
		border-bottom:2px solid black; 
		margin-left: 80px;
	}
	.invoi2 label{
		font-size: 13px;
		font-weight: 500px;
		color: red;
		font-family: caliberi;
	}
	.invoi3 label{
		font-size: 13px;
		font-weight: 500;
		color: red;
		font-family: caliberi;
	}
	.invoi4 label{
		font-size: 13px;
		font-weight: 500;
		color: red;
		font-family: caliberi;
	}
	.invoi4 input{
		width: 25%;
		height: 30px;
		margin-top: 10px;
		margin-left: 37px;
		border-radius: 5px;
		border-bottom: 2px solid black;
	}
	.invoi6 input{
		width: 25%;
		height: 30px;
		margin-top: 10px;
		margin-left: 45px;
		border-radius: 5px;
		border-bottom: 2px solid black;
	}
	.invoi7 input{
		width: 40%;
		height: 30px;
		margin-top: 10px;
		margin-left: 80px;
		border-radius: 5px;
		border-bottom: 2px solid black;
	}
	.invoi8 {
		margin-left: 40%;
	}
	.input4{
		width: 20%;
		height: 30px;
		margin-left: 100px;
		border:none;

	}
	.input5{
		width: 70px;
		height: 30px;
		margin-left: 20px;
		border:none;

	}
	.input3{
		margin-left: 29em;
		width: 30%;
		height: 30px;
		border:none;

	}
	.input6{
		width: 30%;
		height: 30px;
		margin-left: 89px;
		border:none;

	}
	.input7{
		width: 20%;
		height: 30px;
		margin-left: 20px;
		border:none;
	}
	.input8{
		width: 30%;
		height: 30px;
		margin-left: 89px;
		border:none;	
	}
	.input9{
	    width: 30%;
		height: 30px;
		margin-left: 31em;
		border:none;
	}
.invoi5 label{
		font-size:13px;
		font-weight: 500;
		color: red;
		font-family: caliberi;
	}
	.invoi6 label{
		font-size:13px;
		font-weight: 500;
		color: red;
		font-family: caliberi;
	}
	.invoi7 label{
		font-size:13px;
		font-weight: 500;
		color: red;
		font-family: caliberi;
	}
	.invoi8 label{
		font-size:13px;
		font-weight: 500;
		color: red;
		font-family: caliberi;
	}

.input2{
		width: 25%;
		height: 30px;
		border-radius: 5px;
		border-bottom:2px solid black; 
}
.invoi5 select {
	width: 15%;
	height: 30px;
	margin-left: 2px;
	border-radius: 5px ;
	border-bottom: 2px solid ;

}
.slabel{
	margin-left: 15px;
}
.input1{
	width: 25%;
		height: 30px;
		margin-left: 80px;
		border-radius: 5px;
		border-bottom:2px solid black;

}
  th{
	border:2px solid;
}
button {
	background-color: red;
	color: white;
}

</style>
<section id="main-content">
      <section class="wrapper">
      	<?php
                  $a2=$_GET['id'];

                  $link=mysqli_connect("localhost","root","","vgs");
                   if($link==false)
                   {
                    die("error:cant connect".mysqli_connect_error());
                   }
                   $sql="SELECT*FROM invoicenew where invoiceno='$a2'";
                   if($result=mysqli_query($link,$sql))
                   {
                    if(mysqli_num_rows($result)>0)
                    { 
                      
                      while($row= mysqli_fetch_array($result))

                    {
                    
                     ?>    

    <form action="updatein.php" method="POST">
      <div class="invoi1">
      <p><i class="fa fa-file-text"></i>EDIT INVOICE</p>
      </div><br>
    <form action="insertin.php" method="post">
      <div class="invoi2">	
       <label>CUSTOMER NAME</label>
        <input type="text" name="c0" value="<?php echo$row['customername'];?>">
    </div><br><br>
    <div class="invoi3">	
       <label>INVOICE#</label>
        <input type="text" name="c1" value="<?php echo$row['invoiceno'];?>" >
    </div>
    <div class="invoi4">	
       <label>ORDER NUMBER</label>
        <input type="text" name="c2"value="<?php echo$row['orderno'];?>">
    </div>
    <div class="invoi5">	
       <label>INVOICE DATE</label>
        <input class="input1" type="date" name="c3" value="<?php echo$row['invoicedate'];?>">
       <span class="slabel"><label>TERMS</label> </span>
        <select name="c4" value="<?php echo$row['terms'];?>">
        	<option>DUE ON RECEIPT</option>
            <option>DUE END OF THE MONTH</option>
             <option>DUE END OF NEXT MONTH</option>
              <option>NET 50</option>
                  <option>NET 30</option>
               
        </select>
       <label>DUE DATE</label>
      <input class="input2" type="date" name="c5" value="<?php echo$row['duedate'];?>">
    </div><br><br>
    <div class="invoi6">	
       <label>SALESPERSON</label>
        <input type="text" name="c6" value="<?php echo$row['salesperson'];?>">
    </div><br><br><br>
    <div class="invoi7">	
       <label>SUBJECT</label>
        <input type="text" name="c7" value="<?php echo$row['subject'];?>">
    </div><br>
    <table class="table table-bordered">
    	<tr style="border:2px solid black;">
    		<th>item details</th>
    		<th>Quantity</th>
    		<th>rate</th>
    		<th>discount</th>
    		<th>amount</th>
    	</tr>
    	<tr>
    		<td name="tc1" value="<?php echo$row['itemdetails'];?>">wadksk</td>
    		<td name="tc2" value="<?php echo$row['quantity'];?>">53267</td>
    		<td name="tc3" value="<?php echo$row['rate'];?>">378</td>
    		<td name="tc4" value="<?php echo$row['discount'];?>">10%</td>
    		<td name="tc5" value="<?php echo$row['amount'];?>">57688</td>
    	</tr>
    </table>
    <button type="AddItem" class="btn btn-round btn-primary">
    <i class=" fa fa-plus"> Add Item</i></button></a><br><br>
    <div class="invoi8">
    	 <label>SUBTOTAL</label>
    	 <input class="input3" type="text" name="c8" value="<?php echo$row['subtotal'];?>"><br><br><br>
    	 <label>TAX</label>
    	 <input class="input4" type="text" name="c9" >
    	<input  class="input5" type="NUMBER" name="c10">
    	<input class="input6" type="text" name="c11" value="<?php echo$row['tax'];?>"><br><br>
    	<label>OTHER CHARGES</label>
    	 <input class="input7" type="text" name="c12" >
    	 <input  class="input5" type="NUMBER" name="c13">
    	 <input class="input8" type="text" name="c14" value="<?php echo$row['othercharges'];?>"><br><br>
    <label>TOTAL</label>
    	 <input class="input9" type="text" name="c15" value="<?php echo$row['total'];?>">
    </div><br><br>
    <div class="invoi9">
    	<label>TERMSCONDITION</label><br>
    	<textarea style="width: 40%; height: 70px; border:none;" name="c16" value="<?php echo$row['termscondition'];?>"></textarea><br>
    	<label>ATTACH FILEINVOICE</label>
    	<input type="file" name="c17" value="<?php echo$row['attachfile'];?>"><br>
    	 </div>
    	 <input style="background-color:skyblue; color:white; width: 50px;" type="submit"  value="save">
    </form>
     <?php  } } }?>
      </section>
</section>