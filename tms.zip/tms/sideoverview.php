<style>
.vl {
  border-left: 1px solid skyblue;
  height:515px;
  float: right;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 45%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.righ{
    float: right;
    margin-right: 30%;
    margin-left: 50px;
}
.spac{
    margin-left: 30px;
}
.top{
    margin-top: 50px;
}


</style>
</head>
  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->


<body>


    <!-- all item view
 -->  
 <div class="righ">
<table>
    <tr>
        <td>overview</td>
        <td>transaction</td>
        <td>history</td>
<!--         <td>Edit item ></td>
 -->
    </tr> 
    </table><br>
    <table>
        
</table><br>

<span>Item type:</span><span class="spac">sales item<br>
<span>unit     &nbsp;</span><span class="spac">:  1kg<br>

<span>created by:</span> <span class="spac">user</span><br><br>

<h3>Sales Information</h3><br>
<span>Selling Price:</span> <span class="spac">  ₹13,300.00</span><br>
<span>Description  :</span> <span class="spac">  c122 quality item</span>
<br> 
<a href="edititem.php">    
<button i class="fa fa-pencil top" >Edit</button>
</a>
     <?php
$link=mysqli_connect("localhost","root","","vgs");
if($link==false)
{
  die("error:cant connect".mysqli_connect_error());

}
$sql="SELECT*FROM newitem ";
if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
  echo "<table border='3'>";
  echo"<tr>";
  // echo "<th>itemno</th>";
  // echo"<th>type</th>";
  echo"<th>name</th>";
  // echo"<th>unit</th><br>";
  // echo"<th>sellingprice</th>";
  // echo"<th>description</th>";
  // echo"<th>date</th>";
  echo"</tr>";
  while($row= mysqli_fetch_array($result))
  {
  echo"<tr>";
  // echo "<td>".$row['itemno']."</td>";
  // echo"<td>".$row['type']."</td>";
  echo"<td>".$row['name']."</td>";
  // echo"<td>".$row['unit']."</td>";
  // echo"<td>".$row['sellingprice']."</td>";
  // echo"<td>".$row['description']."</td>";
  // echo"<td>".$row['date']."</td>";

  echo"</tr>";

  }
  echo"</table>";
  mysqli_free_result($result);
}
else
{
  echo"no match found";
}
}
else
{
  echo"error;cant execute $sql.".mysqli_error($link);
}
mysqli_close($link);

?>
</div>  