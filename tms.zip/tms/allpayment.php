<?php
include ("head.php");
include("nav.php");
 ?>
 <style>
     
 </style>
 <section id="main-content">
      <section class="wrapper">
          <!-- page start-->
    <!-- row -->
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                  <a href="newestimate.php">
                    <button type="AddItem" class="btn btn-round btn-primary" style="float: right; margin-right: 20px;">
                      <i class=" fa fa-plus">New Payment</i></button></a>
                <h4>  
                  <select name="" onchange="location=this.value" >
                    <option value="allestimat.php">All Payment</option>
                    <option value="declinedetimate.php">Declined Estimate</option>
                    <option value="acceptedstimate.php">Accepted Estimate</option>
                 </select>
               </h4>
               

                <hr>
                <thead>
                  <tr>
                    <th><i class="fa fa-bookmark"></i> Date</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> EstimateNumber</th>
                    <th><i class="fa fa-money"></i> Customername</th>
                    <th><i class=" fa fa-bullhorn"></i> Status</th>
                    <th><i class=" fa fa-money"></i>Amount</th>
                    <th><i class=" fa fa-edit"></i>Editchanges</th>

                  </tr>
                </thead>
                <tbody>    
    <!-- row -->
                 <tr>
                    <td>
                      <a href="basic_table.html#"><--?php echo$row['name']; ?--></a>
                    </td>
                    <td class="hidden-phone"><--?php echo$row['description']; ?--></td>
                    <td><-- ?php echo$row['sellingprice']; ?> --></td>
                    <td><-- ?php echo$row['sellingprice']; ?> --></td>

                    <td><span class="label label-info label-mini">-----</span></td>
                    <td>
                      <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                      <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                      <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                    </td>
                  </tr>
                 
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->




      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->








