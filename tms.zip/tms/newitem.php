<?php
include ("head.php");
include("nav.php");
 ?>
 
  <style>
    .spacer{
       margin-right: 50px;

    }
    .top{
      margin-top: 30px;
      background-color: ghostwhite;
    }
    
  </style>

  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->


<form action="tblnewitem.php" method="POST">
<h3>New student</h3>
<!-- <label class="spacer">Type</label>
<input type="radio"  name="r1" value="product">
<label>product</label>
  <input type="radio" name="r1" value="service"> -->
  <!-- <label>student name</label><br><br> -->
    <label>student name</label><br>
    <input type="text" name="r2"><br><br>
        <label for="browser">duration</label><br>
        <input list="unit" placeholder="eg:kg,ltr,pcs,pkt" name="r3" >
          <datalist id="unit">
            <option value="kilogram">
            <option value="liter">
            <option value="pockets">
           <option value="pieaces">
          </datalist> 
                  <br><br>

    <label>selling price</label><br><input type="text" name="r4"><br><br>
      <label>  Description</label><br><input type="text" name="r5"><br><br>
            <label>Date</label><br><input type="date" name="r6"
                   value="<?php echo date('Y-m-d'); ?>"> <br><br>

           <button class="btn btn-theme" type="submit">Save</button>
            <button class="btn btn-theme04" type="reset">Cancel</button>
<?php 
header("location:newitem.php");
?>


<!-- item added successfully notification -->

   <!-- /wrapper -->
    </section>
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->



