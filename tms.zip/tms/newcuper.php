<?php
include ("nav.php");
?>
<?php
include ("side.php");
?>
<section id="main-content">
      <section class="wrapper">
<!-- page start-->
      <!-- <div class="header"> -->
        <p style="font-size: 28px; margin-left: 11em;" >NEW CUSTOMER</p>
        <label>customer tybe</label>
        <input  style="margin-left: 40px;" type="radio" name="customer_choice">
        <label>individual</label>
        <input type="radio" name="customer_choice">
        <label>business</label><br><br>
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">CUSTOMER NAME</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control"><br>
                  </div>
    </div>
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">COMPANY NAME</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;"  type="text" class="form-control"><br>
                  </div>
    </div>
    <div class="form-group">
                <label class="col-sm-2 col-sm-2 control-label">CUSTOMER PHONE</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control"><br>
                  </div>
    </div>
    <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">CUSTOMER Email</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control"><br>
                  </div>
    </div>
    <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label">CUSTOMER WEBSITE</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control"><br>
                  </div>
    </div>
     <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label">PAN</label>
                  <div class="col-sm-10">
                    <input style="width: 20em;" type="text" class="form-control"><br>
                  </div>
    </div>
     <div class="form-group">
              <label class="col-sm-2 col-sm-2 control-label">PAYMENT TERMS</label>
                   <select style="width: 20em; height: 30PX; margin-left: 20px;">
                  <option>DUE ON RECEIPT</option>
                  <option>DUE END OF THE MONTH</option>
                  <option>DUE END OF NEXT MONTH</option>
                  <option>NET 50</option>
                  <option>NET 30</option>
                </select>
    </div>
    <a href="newcuadd.php"><button type="button" class="btn btn-round btn-primary">ADDRESS</button></a>
      <a href="newcuper.php"><button type="button" class="btn btn-round btn-success">CONTACT PERSONS</button></a>
      <a href="newcure.php"> <button type="button" class="btn btn-round btn-info">REMARKS</button></a><br><br>
       <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                    <th>email</th>
                    <th>phone</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td >1</td>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                    <td>eudksja@sdj.com</td>
                    <td>87239102</td>
                  </tr>
                </tbody>
              </table>


     
      </section>
      <!-- /wrapper -->
    </section>