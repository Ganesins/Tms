<?php
include
 ("head.php");
include("nav.php");
 ?>


<style>
.vl {
  border-left: 1px solid skyblue;
  height:515px;
  float: right;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 45%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.righ{
    float: right;
    margin-right: 30%;
    margin-left: 50px;
}
.spac{
    margin-left: 30px;
}
.top{
    margin-top: 50px;
}

</style>
</head>
  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->

<body>

<h3>
    <select>
        <option>All payment</option>
    </select>
    <a href="newpayment.php">
        <button type="AddItem" class="btn btn-round btn-primary" 
        style="margin: 5px;">
             <i class=" fa fa-plus">New payment</i></button></a>
</h3>




<!-- all item view
 -->  
 <div class="righ">
<table>
    <tr>
        <td>overview</td>
        <td>transaction</td>
        <td>history</td>
<!--         <td>Edit item ></td>
 -->
    </tr> 
    </table><br>
    <table>
        
</table><br>

<span>Item type:</span><span class="spac">sales item<br>
<span>unit     &nbsp;</span><span class="spac">:  1kg<br>

<span>created by:</span> <span class="spac">user</span><br><br>

<h3>Sales Information</h3><br>
<span>Selling Price:</span> <span class="spac">  ₹13,300.00</span><br>
<span>Description  :</span> <span class="spac">  c122 quality item</span>
<br> 
<a href="edititem.php">    
<button i class="fa fa-pencil top" >Edit</button>
</a>
</div>  
<div class="vl"></div>

<table>
 <th>
     <tr>
         <th>Name</th>
         <th>date</th>
         <th>paymentmode</th>
     </tr>

 </th>
 <tr>
     <td>divya</td>
     <td>12/3/444</td>
     <td>Gpay</td>
 </tr>
  

</body>
</html>

<!-- /wrapper -->
    </section>
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
