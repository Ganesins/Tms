<?php
$x0=$_POST['a0'];
$x1=$_POST['a1'];
$x2=$_POST['a2'];
$x3=$_POST['a3'];
$x4=$_POST['a4'];
$x5=$_POST['a5'];
$x6=$_POST['a6'];
$x7=$_POST['a7'];
$link=mysqli_connect("localhost","root","","vgs");

if($link==false)
{
	die("Error:could not connect.".mysqliconnect_error());
}
$sql="INSERT INTO newcustomer(customertype,customername,companyname,customerphone,customeremail,customerwebsite,pan,paymentterms) VALUES ('$x0','$x1','$x2','$x3','$x4','$x5','$x6','$x7')";
echo "$sql";
if(mysqli_query($link,$sql))
{
echo"records added successfully";
}

else{
	echo "ERROR:COULD NOT BE EXECUTE $sql.".mysqli_error($link);
}
echo "working";
mysqli_close($link);

?>
