<?php
include
 ("head.php");
include("nav.php");
include("sideoverview.php");
?>

  
<div class="vl"></div>
    <h2>Item</h2>

    <table >
 <th>
     <tr>
         <th>ItemName
         </th>
     </tr>

 </th>
 <tbody>

     <?php
$link=mysqli_connect("localhost","root","","vgs");
if($link==false)
{
  die("error:cant connect".mysqli_connect_error());

}
$sql="SELECT*FROM newitem ";
if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
  // echo "<table border='3'>";
  // echo"<tr>";
  // echo "<th>itemno</th>";
  // echo"<th>type</th>";
  // echo"<th>name</th>";
  // echo"<th>unit</th><br>";
  // echo"<th>sellingprice</th>";
  // echo"<th>description</th>";
  // echo"<th>date</th>";
  // echo"</tr>";
  while($row= mysqli_fetch_array($result))
  {
//   echo"<tr>";
//   echo "<td>".$row['itemno']."</td>";
//   echo"<td>".$row['type']."</td>";
//   echo"<td>".$row['name']."</td>";
//   echo"<td>".$row['unit']."</td>";
//   echo"<td>".$row['sellingprice']."</td>";
//   echo"<td>".$row['description']."</td>";
//   echo"<td>".$row['date']."</td>";

//   echo"</tr>";

//   }
//   echo"</table>";
//   mysqli_free_result($result);
// }
// else
// {
//   echo"no match found";
// }
// }
// else
// {
//   echo"error;cant execute $sql.".mysqli_error($link);
// }
// mysqli_close($link);

?>
     <tr>
                    <td>
                      <a href="itemoverview.php"><?php echo$row['name']; ?></a>
                    </td>
                   
                  <?php  }  } } ?>
                </tbody>
              </table>
          </tr>
      </tbody>
  </div>






</body>
</html>

<!-- /wrapper -->
    </section>
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
