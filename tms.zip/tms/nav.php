 <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>TMS-Admin </title>

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <script src="lib/chart-master/Chart.js"></script>
</head>
 <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">Sam Soffes</h5>
          <li class="mt">
            <a class="active" href="index.html">
              <i class="fa fa-dashboard"></i>
              <span>Dash</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span>Admin Master</span>
              </a>
            <ul class="sub">
              <li><a href="newcourse.php">New course</a></li>
              <li><a href="allcourse.php">All course</a></li>
              <!-- <li><a href="activecu.php">active customers</a></li>
              <li><a href="inactivecu.php">inactive customers</a></li>
              <li><a href="overduecu.php">overdue Customer</a></li>
              <li><a href="unpaidcu.php">Unpaid Customer</a></li> -->
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-cogs"></i>
              <span>Student Master</span>
              </a>
            <ul class="sub">
                <li><a href="newstu.php">New student</a></li>
              <li><a href="allstu.php">All student</a></li>
              <!-- <li><a href="activeitems.php">Active items</a></li>
              <li><a href="inactiveitems.php">Inactive items</a></li>
               -->
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Assign Master</span>
              </a>
            <ul class="sub">
              <li><a href=".php">Assign course</a></li>
              <li><a href=".php">Assign faculty</a></li>
          
            </ul>
          </li>


          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>invoice</span>
              </a>
            <ul class="sub">
              <li><a href="invoic.php"></a></li>
              <li><a href="allinvoic.php">All Invoice</a></li>
              <li><a href="#">Paid Invoice</a></li>
              <li><a href="#">Unpaid Invoice</a></li>
              <!-- <li><a href="contactform.html">Contact Form</a></li> -->
            </ul>
          </li>
          
          
          <li class="sub-menu">
            <a href="javascript:;">
              <i class=" fa fa-bar-chart-o"></i>
              <span>Fees Payment</span>
              </a>
            <ul class="sub">
              <li><a href="newpayment.php">New Payment</a></li>
              <li><a href="allpayment.php">Allreceivable Payments</a></li>
              <!-- <li><a href="chartjs.html">Chartjs</a></li>
              <li><a href="flot_chart.html">Flot Charts</a></li>
              <li><a href="xchart.html">xChart</a></li> -->
            </ul>
          </li>
          <li>


            <a href="inbox.html">
              <i class="fa fa-envelope"></i>
              <span>report</span>
              <span class="label label-theme pull-right mail-info">2</span>
              </a>
          </li>
           <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span>Faculty</span>
              </a>
            <ul class="sub">
              <li><a href="newcu.php">New course</a></li>
              <li><a href="allcourse.php">All customers</a></li>
             <!--  <li><a href="activecu.php">active customers</a></li>
              <li><a href="inactivecu.php">inactive customers</a></li> -->
              <li><a href="overduecu.php">overdue Customer</a></li>
              <li><a href="unpaidcu.php">Unpaid Customer</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-cogs"></i>
              <span>Attendence</span>
              </a>
            <ul class="sub">
                <li><a href="newitem.php">New Items</a></li>
              <li><a href="allitems.php">All items</a></li>
              <li><a href="activeitems.php">Active items</a></li>
              <li><a href="inactiveitems.php">Inactive items</a></li>
              
            </ul>
          </li>


         <!-- sidebar menu end-->
      </div>
    </aside>
  </ul>
</div>
</aside>
    <!--sidebar end-->
    <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>

  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="lib/jquery.scrollTo.min.js"></script>
  <script src="lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="lib/common-scripts.js"></script>
  <script type="text/javascript" src="lib/gritter/js/jquery.gritter.js"></script>
  <script type="text/javascript" src="lib/gritter-conf.js"></script>
  <!--script for this page-->
  <script src="lib/sparkline-chart.js"></script>
  <script src="lib/zabuto_calendar.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      var unique_id = $.gritter.add({
        // (string | mandatory) the heading of the notification
        // title: 'Ready to Bill',
        // (string | mandatory) the text inside the notification
        // text: 'Another Profitable Day :)',
        // (string | optional) the image to display on the left
        // image: 'img/ny.jpg',
        // (bool | optional) if you want it to fade out on its own or just sit there
        sticky: false,
        // (int | optional) the time you want it to be alive for before fading out
        time: 1000,
        // (string | optional) the class name you want to apply to that specific message
        class_name: 'my-sticky-class'
      });

      return false;
    });
  


  </script>
  <script type="application/javascript">
    $(document).ready(function() {
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });
    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
  </script>
</body>
</html>


   


