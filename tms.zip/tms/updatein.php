<?php
$a0=$_POST['c0'];
$a1=$_POST['c1'];
$a2=$_POST['c2'];
$a3=$_POST['c3'];
$a4=$_POST['c4'];
$a5=$_POST['c5'];
$a6=$_POST['c6'];
$a7=$_POST['c7'];
$a8=$_POST['c8'];
$a9=$_POST['c11'];
$a10=$_POST['c14'];
$a11=$_POST['c15'];
$a12=$_POST['c16'];
$a13=$_POST['c17'];
$a15=$_POST['tc1'];
$a16=$_POST['tc2'];
$a17=$_POST['tc3'];
$a18=$_POST['tc4'];
$a19=$_POST['tc5'];
$link = mysqli_connect("localhost","root","","vgs");
if($link==false)
  {
	die("ERROR:COULD NOT BE CONNECT.".mysqli_connect_error());
  }
  $sql = "UPDATE `invoicenew` SET `customername`='$a0',`invoiceno`='$a1',`orderno`='$a2',`invoicedate`='$a3',`terms`='$a4',`duedate`='$a5',`salesperson`='$a6',`subject`='$a7',`itemdetails`='$a15',`quantity`='$a16',`rate`='$a17',`discount`='$a18',`amount`='$a19',`subtotal`='$a8',`tax`='$a9',`othercharges`='$a10',`total`='$a11',`termscondition`='$a12',`attachfile`='$a13'where invoiceno='$a1'";
  if(mysqli_query($link,$sql))
  {
  	echo "records were deleted successfuly.";
  }
  else
  {
  	echo "ERROR:could not able to execute$sql.".mysqli_error($link);

  }
  header("location:allinvoic.php");
  mysqli_close($link);
  ?>
