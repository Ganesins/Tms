<?php
$v1=$_POST['hide1'];
$a4=$_POST['r2'];
$a5=$_POST['r3'];
$a6=$_POST['r4'];
echo$a6;
echo"work";
	$link=mysqli_connect("localhost","root","","tms");
	if($link==false)
	{
			
		
		die("error cant connected".mysqliconnect_error());
	}
	
	
// $sql="DELETE FROM `newitem` WHERE itemno='$a2'";

// $sql="UPDATE `master`SET type='$a3',name='$a4',unit='$a5',sellingprice='$a6',description='$a7' where itemno='$v1'";

$sql="UPDATE `master`SET course='$a4',package='$a5',duration='$a6'WHERE id='$v1'";

echo$sql;

	if(mysqli_query($link,$sql))

	{
		echo"records updated succssfully";
	}
	else
	{
		echo"cant able to excecuted".mysqli_error($link);
	}
	
	header("location:allcourse.php");
	mysqli_close($link)
?>	