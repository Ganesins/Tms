<?php
include ("head.php");
include("nav.php");
 ?>
  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->
        <a href="newcourse.php">
         <button type="Addcourse" class="btn btn-round btn-primary" style="float: right; margin: 20px; margin:;">
             <i class=" fa fa-plus">New course</i></button></a>

    <h3>All Course</h3>
    <!--   <select name="" onchange="location = this.value;" >
              <option value="allitems.php">All</option>
             <option value="inactiveitems.php">Inactive</option>
             <option value="activeitems.php">Active</option>

      
    </select> -->

  <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <hr>
                <thead>
                  <tr>
                    <th>course id</th>
                    <th><i class="fa fa-bullhorn"></i>COURSE NAME</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> package</th>
                    <th><i class="fa fa-money"></i> Duration</th>
                    <th><i class=" fa fa-bookmark"></i>Action</th>

                    <th></th>
                  </tr>
                </thead>
                <tbody>    
    <!-- row -->
    <?php
$link=mysqli_connect("localhost","root","","tms");
if($link==false)
{
  die("error:cant connect".mysqli_connect_error());

}
$sql="SELECT*FROM master";
if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
  // echo "<table border='3'>";
  // echo"<tr>";
  // echo"<th>type</th>";
  // echo"<th>name</th>";
  // echo"<th>unit</th><br>";
  // echo"<th>sellingprice</th>";
  // echo"<th>description</th>";
  // echo"<th>date</th>";
  // echo"</tr>";
  while($row= mysqli_fetch_array($result))
  {
//   echo"<tr>";
//   echo"<td>".$row['type']."</td>";
//   echo"<td>".$row['name']."</td>";
//   echo"<td>".$row['unit']."</td>";
//   echo"<td>".$row['sellingprice']."</td>";
//   echo"<td>".$row['description']."</td>";
//   echo"<td>".$row['date']."</td>";

//   echo"</tr>";

//   }
//   echo"</table>";
//   mysqli_free_result($result);
// }
// else
// {
//   echo"no match found";
// }
// }
// else
// {
//   echo"error;cant execute $sql.".mysqli_error($link);
// }
// mysqli_close($link);

?>


          
     
                  <tr>
                    <td> <?php echo$row['id'];?></td>
                    <td>
                      <a href=""><?php echo$row['course']; ?></a>
                    </td>
                  <td class="hidden-phone"><?php echo$row['package']; ?></td>
                    <td><?php echo$row['duration']; ?></td>
                 <!--    <td><span><div class="btn-group">
                <button type="button" class="btn btn-theme03">Status</button>
                <button type="button" class="btn btn-theme03 dropdown-toggle" data-toggle="dropdown">
                  <span class="caret"></span>
                  <span class="sr-only">Toggle Dropdown</span>
                  </button> -->
                <ul class="dropdown-menu" role="menu">
                  <li><a href="activeitems.php?id=<?php echo$row['id'];?>">
                  active</a></li>
                  <li><a href="#">inavtive</a></li>
                 
                </ul>
              </div>
            </div></span></td>
                    <td>
                      
                      <!-- <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button-->

                      <a href="edititem.php?id=<?php echo$row['id'];?>">
        <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i>
        </button></a>

                  <a href="delnewitem.php?id=<?php echo $row['id'];?>">
                    <button style="margin-left: 10px;" class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button></a>

                    </td>
                  </tr>
                  <?php  }  } } ?>
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->




      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->








