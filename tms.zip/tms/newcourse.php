<?php
include ("head.php");
include("nav.php");
 ?>
 
  <style>
    .spacer{
       margin-right: 50px;

    }
    .top{
      margin-top: 30px;
      background-color: ghostwhite;
    }
    
  </style>

  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->


<form action="tblnewitem.php" method="POST">
<h3>New Course</h3>
<!-- <label class="spacer">Type</label>
<input type="radio"  name="r1" value="product">
<label>product</label>
  <input type="radio" name="r1" value="service">
  <label>service</label><br><br> -->
    <label>New course</label><br>
    <input type="text" name="r1"><br><br>
        <label >package</label><br>
       <input type="text" name="r2"><br><br>
       <label>Duration</label><br>
       <input type="text" name="r3">
                  <br><br>

   
            <label>Date</label><br><input type="date" name="r6"
                   value="<?php echo date('Y-m-d'); ?>"> <br><br>

           <button class="btn btn-theme" type="submit">Save</button>
            <button class="btn btn-theme04" type="reset">Cancel</button>
<?php 
header("location:newitem.php");
?>


<!-- item added successfully notification -->

   <!-- /wrapper -->
    </section>
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->



