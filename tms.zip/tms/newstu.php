<?php
include ("head.php");
include("nav.php");
 ?>
 
  <style>
    .spacer{
       margin-right: 50px;

    }
    .top{
      margin-top: 30px;
      background-color: ghostwhite;
    }
    
  </style>

  <section id="main-content">
      <section class="wrapper">
      
        <!-- page start-->


<form action="tblnewitem.php" method="POST">
<h3>New student</h3>
<!-- <label class="spacer">Type</label>
<input type="radio"  name="r1" value="product">
<label>product</label>
  <input type="radio" name="r1" value="service"> -->
  <!-- <label>student name</label><br><br> -->
    <label>student name</label><br>
    <input type="text" name=""><br>
       <label>student age</label><br>
    <input type="text" name=""><br>
       <label>student address</label><br>
    <input type="text" name=""><br>
       <label>Father name</label><br>
    <input type="text" name=""><br>
       <label>parents mail id</label><br>
    <input type="email" name=""><br>
       <label>phone no</label><br>
    <input type="phone" name=""><br><br>
       <label>course choosen</label><br>
    <input type="text" name=""><br><br>
    <label>Id proof</label>
    <input type="file" name="">

    
            <label>Date</label><br><input type="date" name="r6"
                   value="<?php echo date('Y-m-d'); ?>"> <br><br>

           <button class="btn btn-theme" type="submit">Save</button>
            <button class="btn btn-theme04" type="reset">Cancel</button>



<!-- item added successfully notification -->

   <!-- /wrapper -->
    </section>
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->



