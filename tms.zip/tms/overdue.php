<?php
include ("nav.php");
?>
<?php
include ("side.php");
?>
<style>
.cus0{
	font-size: 30px;
	font-weight: bold;
}
.new1{
	float: right;
}
	
</style>
<section id="main-content">

      <section class="wrapper">
      	<p class="cus0">ACTIVE CUSTOMER</p>

      	
  <select style="width:10%;" class="cus1" aria-label=".form-select-sm example  ">
  <option value="3">OVERDUE CUSTOMER</option>
  <option selected>ALL CUSTOMER</option>
  <option value="1">ACTIVE CUSTOMER</option>
  <option value="2">INACTIVE CUSTOMER</option>
  <option value="4">UNPAID CUSTOMER</option>
</select>
<div class="new1">
 <a href="newcu.php"><button type="AddItem" class="btn btn-round btn-primary">
  <i class=" fa fa-plus"> Add customer</i></button></a>
 </div>
<div class="row mt">
       <div class="col-md-12">
         <div class="content-panel">
          <table class="table table-striped table-advance table-hover">
                <!-- <h4><i class="fa fa-angle-right"></i> Advanced Table</h4>
                <hr> -->
                <thead>
                  <tr>
                    <th>NAME</th>
                    <th>company name</th>
                    <th>email</th>
                    <th>work phone</th>
                    <th>receivables</th>
                    <th>unused credits</th>
                  </tr>
                </thead>
              <tbody>
                <tr>
                  <td>vel</td>
                  <td>veera computer</td>
                  <td>jaskhuiljl;</td>
                  <td>34567890</td>
                  <td>56278</td>
                  <td>656</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  </section>
            
