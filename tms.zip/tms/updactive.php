


<?php
// $v1=$_POST['hide1'];
// $a3=$_POST['r1'];
// $a4=$_POST['r2'];
// $a5=$_POST['r3'];
// $a6=$_POST['r4'];
// $a7=$_POST['r5'];
            $a1=$_GET['id'];

echo$a1;
echo"work";
  $link=mysqli_connect("localhost","root","","vgs");
  if($link==false)
  {
      
    
    die("error cant connected".mysqliconnect_error());
  }
  
  
// $sql="DELETE FROM `newitem` WHERE itemno='$a2'";

$sql="UPDATE `newitem`SET type='$a3',name='$a4',unit='$a5',sellingprice='$a6',description='$a7' where itemno='$v1'";

echo$sql;

  if(mysqli_query($link,$sql))

  {
    echo"records deleted succssfully";
  }
  else
  {
    echo"cant able to excecuted".mysqli_error($link);
  }
  
  header("location:allitems.php");
  mysqli_close($link)
?>  
